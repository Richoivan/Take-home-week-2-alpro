namespace Richo_0202
{
    public partial class Form1 : Form
    {
        string[] kata = new string[5];
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 5; i++)
            {
                kata[i] = "";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TB1_TextChanged(object sender, EventArgs e)
        {
            kata[0] = TB1.Text;
        }

        private void TB2_TextChanged(object sender, EventArgs e)
        {
            kata[1] = TB2.Text;
        }

        private void TB3_TextChanged(object sender, EventArgs e)
        {
            kata[2] = TB3.Text;
        }

        private void TB4_TextChanged(object sender, EventArgs e)
        {
            kata[3] = TB4.Text;
        }

        private void TB5_TextChanged(object sender, EventArgs e)
        {
            kata[4] = TB5.Text;
        }

        private void button_01_Click(object sender, EventArgs e)
        {
            bool check = false;
            foreach (string totalkata in kata)
            {
                if (totalkata.Length != 5)
                {
                    label_6.Text = "Salah Jumlah huruf tidak sesuai.";
                    check = true;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                kata[i] = kata[i].ToUpper();
            }
            foreach (string totalkata in kata)
            {
                foreach (char k in totalkata)
                {
                    if ("ABCDEFGHIJKLMNOPQRSTUVWXYZ".Contains(k))
                    {

                    }
                    else
                    {
                        check = true;
                        label_6.Text = "Salah Kata Memiliki Angka.";
                        break;
                    }
                }
            }
            for (int i = 0; i < 5; i++)
            {
                for (int j = i + 1; j < 5; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    if (kata[i] == kata[j])
                    {
                        check = true;
                        label_6.Text = "Salah Kata Kembar.";
                        break;
                    }
                }
            }
            if (check)
            {

            }
            else
            {
                label_6.Text = "Betul.";
                Random rnd = new Random();
                string wordle = kata[rnd.Next(0, 5)];
                Game game = new Game(wordle);
                game.ShowDialog();
            }

        }
    }
}
