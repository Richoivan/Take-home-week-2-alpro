﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Richo_0202
{
    public partial class Game : Form
    {
        char[] array = new char[5];
        int betul = 0;
        public Game(string wordle)
        {
            InitializeComponent();
            int angka = 0;
            foreach (char c in wordle)
            {
                array[angka++] = c;
            }
            label_7.Text = wordle;
        }

        private void Game_Load(object sender, EventArgs e)
        {

        }

        private void test()
        {
            if (betul == 5)
            {
                label_6.Text = "Menang";
            }
        }

        private void button_1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'Q')
                {
                    Controls[$"label_{i + 1}"].Text = "Q";
                    betul++;
                }
            }
            test();
        }

        private void button_2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'W')
                {
                    Controls[$"label_{i + 1}"].Text = "W";
                    betul++;
                }
            }
            test();
        }

        private void button_3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'E')
                {
                    Controls[$"label_{i + 1}"].Text = "E";
                    betul++;
                }
            }
            test();
        }

        private void button_4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'R')
                {
                    Controls[$"label_{i + 1}"].Text = "R";
                    betul++;
                }
            }
            test();
        }

        private void button_5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'T')
                {
                    Controls[$"label_{i + 1}"].Text = "T";
                    betul++;
                }
            }
            test();
        }

        private void button_6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'Y')
                {
                    Controls[$"label_{i + 1}"].Text = "Y";
                    betul++;
                }
            }
            test();
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'U')
                {
                    Controls[$"label_{i + 1}"].Text = "U";
                    betul++;
                }
            }
            test();
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'I')
                {
                    Controls[$"label_{i + 1}"].Text = "I";
                    betul++;
                }
            }
            test();
        }

        private void button_9_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'O')
                {
                    Controls[$"label_{i + 1}"].Text = "O";
                    betul++;
                }
            }
            test();
        }

        private void button_10_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'P')
                {
                    Controls[$"label_{i + 1}"].Text = "P";
                    betul++;
                }
            }
            test();
        }

        private void button_11_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'A')
                {
                    Controls[$"label_{i + 1}"].Text = "A";
                    betul++;
                }
            }
            test();
        }

        private void button_12_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'S')
                {
                    Controls[$"label_{i + 1}"].Text = "S";
                    betul++;
                }
            }
            test();
        }

        private void button_13_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'D')
                {
                    Controls[$"label_{i + 1}"].Text = "D";
                    betul++;
                }
            }
            test();
        }

        private void button_14_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'F')
                {
                    Controls[$"label_{i + 1}"].Text = "F";
                    betul++;
                }
            }
            test();
        }

        private void button_15_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'G')
                {
                    Controls[$"label_{i + 1}"].Text = "G";
                    betul++;
                }
            }
            test();
        }

        private void button_16_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'H')
                {
                    Controls[$"label_{i + 1}"].Text = "H";
                    betul++;
                }
            }
            test();
        }

        private void button_17_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'J')
                {
                    Controls[$"label_{i + 1}"].Text = "J";
                    betul++;
                }
            }
            test();
        }

        private void button_18_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'K')
                {
                    Controls[$"label_{i + 1}"].Text = "K";
                    betul++;
                }
            }
            test();
        }

        private void button_19_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'L')
                {
                    Controls[$"label_{i + 1}"].Text = "L";
                    betul++;
                }
            }
            test();
        }

        private void button_20_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'Z')
                {
                    Controls[$"label_{i + 1}"].Text = "Z";
                    betul++;
                }
            }
            test();
        }

        private void button_21_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'X')
                {
                    Controls[$"label_{i + 1}"].Text = "X";
                    betul++;
                }
            }
            test();
        }

        private void button_22_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'C')
                {
                    Controls[$"label_{i + 1}"].Text = "C";
                    betul++;
                }
            }
            test();
        }

        private void button_23_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'V')
                {
                    Controls[$"label_{i + 1}"].Text = "V";
                    betul++;
                }
            }
            test();
        }

        private void button_24_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'B')
                {
                    Controls[$"label_{i + 1}"].Text = "B";
                    betul++;
                }
            }
            test();
        }

        private void button_25_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'N')
                {
                    Controls[$"label_{i + 1}"].Text = "N";
                    betul++;
                }
            }
            test();
        }

        private void button_26_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[i] == 'M')
                {
                    Controls[$"label_{i + 1}"].Text = "M";
                    betul++;
                }
            }
            test();
        }
    }
}
