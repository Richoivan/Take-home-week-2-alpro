﻿namespace Richo_0202
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_1 = new Label();
            label_2 = new Label();
            label_3 = new Label();
            label_4 = new Label();
            label_5 = new Label();
            button_11 = new Button();
            button_12 = new Button();
            button_13 = new Button();
            button_16 = new Button();
            button_15 = new Button();
            button_14 = new Button();
            button_19 = new Button();
            button_18 = new Button();
            button_17 = new Button();
            button_9 = new Button();
            button_8 = new Button();
            button_7 = new Button();
            button_6 = new Button();
            button_5 = new Button();
            button_4 = new Button();
            button_3 = new Button();
            button_2 = new Button();
            button_1 = new Button();
            button_10 = new Button();
            button_26 = new Button();
            button_25 = new Button();
            button_24 = new Button();
            button_23 = new Button();
            button_22 = new Button();
            button_21 = new Button();
            button_20 = new Button();
            label_6 = new Label();
            label_7 = new Label();
            SuspendLayout();
            // 
            // label_1
            // 
            label_1.AutoSize = true;
            label_1.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_1.Location = new Point(222, 72);
            label_1.Name = "label_1";
            label_1.Size = new Size(30, 34);
            label_1.TabIndex = 0;
            label_1.Text = "_";
            // 
            // label_2
            // 
            label_2.AutoSize = true;
            label_2.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_2.Location = new Point(258, 72);
            label_2.Name = "label_2";
            label_2.Size = new Size(30, 34);
            label_2.TabIndex = 1;
            label_2.Text = "_";
            // 
            // label_3
            // 
            label_3.AutoSize = true;
            label_3.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_3.Location = new Point(294, 72);
            label_3.Name = "label_3";
            label_3.Size = new Size(30, 34);
            label_3.TabIndex = 2;
            label_3.Text = "_";
            // 
            // label_4
            // 
            label_4.AutoSize = true;
            label_4.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_4.Location = new Point(330, 72);
            label_4.Name = "label_4";
            label_4.Size = new Size(30, 34);
            label_4.TabIndex = 3;
            label_4.Text = "_";
            // 
            // label_5
            // 
            label_5.AutoSize = true;
            label_5.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_5.Location = new Point(366, 72);
            label_5.Name = "label_5";
            label_5.Size = new Size(30, 34);
            label_5.TabIndex = 4;
            label_5.Text = "_";
            // 
            // button_11
            // 
            button_11.Location = new Point(110, 228);
            button_11.Name = "button_11";
            button_11.Size = new Size(64, 59);
            button_11.TabIndex = 5;
            button_11.Text = "a";
            button_11.UseVisualStyleBackColor = true;
            button_11.Click += button_11_Click;
            // 
            // button_12
            // 
            button_12.Location = new Point(180, 228);
            button_12.Name = "button_12";
            button_12.Size = new Size(64, 59);
            button_12.TabIndex = 6;
            button_12.Text = "s";
            button_12.UseVisualStyleBackColor = true;
            button_12.Click += button_12_Click;
            // 
            // button_13
            // 
            button_13.Location = new Point(250, 228);
            button_13.Name = "button_13";
            button_13.Size = new Size(64, 59);
            button_13.TabIndex = 7;
            button_13.Text = "d";
            button_13.UseVisualStyleBackColor = true;
            button_13.Click += button_13_Click;
            // 
            // button_16
            // 
            button_16.Location = new Point(463, 228);
            button_16.Name = "button_16";
            button_16.Size = new Size(64, 59);
            button_16.TabIndex = 10;
            button_16.Text = "h";
            button_16.UseVisualStyleBackColor = true;
            button_16.Click += button_16_Click;
            // 
            // button_15
            // 
            button_15.Location = new Point(393, 228);
            button_15.Name = "button_15";
            button_15.Size = new Size(64, 59);
            button_15.TabIndex = 9;
            button_15.Text = "g";
            button_15.UseVisualStyleBackColor = true;
            button_15.Click += button_15_Click;
            // 
            // button_14
            // 
            button_14.Location = new Point(323, 228);
            button_14.Name = "button_14";
            button_14.Size = new Size(64, 59);
            button_14.TabIndex = 8;
            button_14.Text = "f";
            button_14.UseVisualStyleBackColor = true;
            button_14.Click += button_14_Click;
            // 
            // button_19
            // 
            button_19.Location = new Point(673, 228);
            button_19.Name = "button_19";
            button_19.Size = new Size(64, 59);
            button_19.TabIndex = 13;
            button_19.Text = "l";
            button_19.UseVisualStyleBackColor = true;
            button_19.Click += button_19_Click;
            // 
            // button_18
            // 
            button_18.Location = new Point(603, 228);
            button_18.Name = "button_18";
            button_18.Size = new Size(64, 59);
            button_18.TabIndex = 12;
            button_18.Text = "k";
            button_18.UseVisualStyleBackColor = true;
            button_18.Click += button_18_Click;
            // 
            // button_17
            // 
            button_17.Location = new Point(533, 228);
            button_17.Name = "button_17";
            button_17.Size = new Size(64, 59);
            button_17.TabIndex = 11;
            button_17.Text = "j";
            button_17.UseVisualStyleBackColor = true;
            button_17.Click += button_17_Click;
            // 
            // button_9
            // 
            button_9.Location = new Point(637, 163);
            button_9.Name = "button_9";
            button_9.Size = new Size(64, 59);
            button_9.TabIndex = 22;
            button_9.Text = "o";
            button_9.UseVisualStyleBackColor = true;
            button_9.Click += button_9_Click;
            // 
            // button_8
            // 
            button_8.Location = new Point(567, 163);
            button_8.Name = "button_8";
            button_8.Size = new Size(64, 59);
            button_8.TabIndex = 21;
            button_8.Text = "i";
            button_8.UseVisualStyleBackColor = true;
            button_8.Click += button_8_Click;
            // 
            // button_7
            // 
            button_7.Location = new Point(497, 163);
            button_7.Name = "button_7";
            button_7.Size = new Size(64, 59);
            button_7.TabIndex = 20;
            button_7.Text = "u";
            button_7.UseVisualStyleBackColor = true;
            button_7.Click += button_7_Click;
            // 
            // button_6
            // 
            button_6.Location = new Point(427, 163);
            button_6.Name = "button_6";
            button_6.Size = new Size(64, 59);
            button_6.TabIndex = 19;
            button_6.Text = "y";
            button_6.UseVisualStyleBackColor = true;
            button_6.Click += button_6_Click;
            // 
            // button_5
            // 
            button_5.Location = new Point(357, 163);
            button_5.Name = "button_5";
            button_5.Size = new Size(64, 59);
            button_5.TabIndex = 18;
            button_5.Text = "t";
            button_5.UseVisualStyleBackColor = true;
            button_5.Click += button_5_Click;
            // 
            // button_4
            // 
            button_4.Location = new Point(287, 163);
            button_4.Name = "button_4";
            button_4.Size = new Size(64, 59);
            button_4.TabIndex = 17;
            button_4.Text = "r";
            button_4.UseVisualStyleBackColor = true;
            button_4.Click += button_4_Click;
            // 
            // button_3
            // 
            button_3.Location = new Point(214, 163);
            button_3.Name = "button_3";
            button_3.Size = new Size(64, 59);
            button_3.TabIndex = 16;
            button_3.Text = "e";
            button_3.UseVisualStyleBackColor = true;
            button_3.Click += button_3_Click;
            // 
            // button_2
            // 
            button_2.Location = new Point(144, 163);
            button_2.Name = "button_2";
            button_2.Size = new Size(64, 59);
            button_2.TabIndex = 15;
            button_2.Text = "w";
            button_2.UseVisualStyleBackColor = true;
            button_2.Click += button_2_Click;
            // 
            // button_1
            // 
            button_1.Location = new Point(74, 163);
            button_1.Name = "button_1";
            button_1.Size = new Size(64, 59);
            button_1.TabIndex = 14;
            button_1.Text = "q";
            button_1.UseVisualStyleBackColor = true;
            button_1.Click += button_1_Click;
            // 
            // button_10
            // 
            button_10.Location = new Point(707, 163);
            button_10.Name = "button_10";
            button_10.Size = new Size(64, 59);
            button_10.TabIndex = 23;
            button_10.Text = "p";
            button_10.UseVisualStyleBackColor = true;
            button_10.Click += button_10_Click;
            // 
            // button_26
            // 
            button_26.Location = new Point(611, 293);
            button_26.Name = "button_26";
            button_26.Size = new Size(64, 59);
            button_26.TabIndex = 30;
            button_26.Text = "m";
            button_26.UseVisualStyleBackColor = true;
            button_26.Click += button_26_Click;
            // 
            // button_25
            // 
            button_25.Location = new Point(541, 293);
            button_25.Name = "button_25";
            button_25.Size = new Size(64, 59);
            button_25.TabIndex = 29;
            button_25.Text = "n";
            button_25.UseVisualStyleBackColor = true;
            button_25.Click += button_25_Click;
            // 
            // button_24
            // 
            button_24.Location = new Point(471, 293);
            button_24.Name = "button_24";
            button_24.Size = new Size(64, 59);
            button_24.TabIndex = 28;
            button_24.Text = "b";
            button_24.UseVisualStyleBackColor = true;
            button_24.Click += button_24_Click;
            // 
            // button_23
            // 
            button_23.Location = new Point(401, 293);
            button_23.Name = "button_23";
            button_23.Size = new Size(64, 59);
            button_23.TabIndex = 27;
            button_23.Text = "v";
            button_23.UseVisualStyleBackColor = true;
            button_23.Click += button_23_Click;
            // 
            // button_22
            // 
            button_22.Location = new Point(328, 293);
            button_22.Name = "button_22";
            button_22.Size = new Size(64, 59);
            button_22.TabIndex = 26;
            button_22.Text = "c";
            button_22.UseVisualStyleBackColor = true;
            button_22.Click += button_22_Click;
            // 
            // button_21
            // 
            button_21.Location = new Point(258, 293);
            button_21.Name = "button_21";
            button_21.Size = new Size(64, 59);
            button_21.TabIndex = 25;
            button_21.Text = "x";
            button_21.UseVisualStyleBackColor = true;
            button_21.Click += button_21_Click;
            // 
            // button_20
            // 
            button_20.Location = new Point(188, 293);
            button_20.Name = "button_20";
            button_20.Size = new Size(64, 59);
            button_20.TabIndex = 24;
            button_20.Text = "z";
            button_20.UseVisualStyleBackColor = true;
            button_20.Click += button_20_Click;
            // 
            // label_6
            // 
            label_6.AutoSize = true;
            label_6.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_6.Location = new Point(519, 79);
            label_6.Name = "label_6";
            label_6.Size = new Size(0, 26);
            label_6.TabIndex = 31;
            // 
            // label_7
            // 
            label_7.AutoSize = true;
            label_7.Location = new Point(47, 402);
            label_7.Name = "label_7";
            label_7.Size = new Size(0, 20);
            label_7.TabIndex = 32;
            // 
            // Game
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label_7);
            Controls.Add(label_6);
            Controls.Add(button_26);
            Controls.Add(button_25);
            Controls.Add(button_24);
            Controls.Add(button_23);
            Controls.Add(button_22);
            Controls.Add(button_21);
            Controls.Add(button_20);
            Controls.Add(button_10);
            Controls.Add(button_9);
            Controls.Add(button_8);
            Controls.Add(button_7);
            Controls.Add(button_6);
            Controls.Add(button_5);
            Controls.Add(button_4);
            Controls.Add(button_3);
            Controls.Add(button_2);
            Controls.Add(button_1);
            Controls.Add(button_19);
            Controls.Add(button_18);
            Controls.Add(button_17);
            Controls.Add(button_16);
            Controls.Add(button_15);
            Controls.Add(button_14);
            Controls.Add(button_13);
            Controls.Add(button_12);
            Controls.Add(button_11);
            Controls.Add(label_5);
            Controls.Add(label_4);
            Controls.Add(label_3);
            Controls.Add(label_2);
            Controls.Add(label_1);
            Name = "Game";
            Text = "Game";
            Load += Game_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_1;
        private Label label_2;
        private Label label_3;
        private Label label_4;
        private Label label_5;
        private Button button_11;
        private Button button_12;
        private Button button_13;
        private Button button_16;
        private Button button_15;
        private Button button_14;
        private Button button_19;
        private Button button_18;
        private Button button_17;
        private Button button_9;
        private Button button_8;
        private Button button_7;
        private Button button_6;
        private Button button_5;
        private Button button_4;
        private Button button_3;
        private Button button_2;
        private Button button_1;
        private Button button_10;
        private Button button_26;
        private Button button_25;
        private Button button_24;
        private Button button_23;
        private Button button_22;
        private Button button_21;
        private Button button_20;
        private Label label_6;
        private Label label_7;
    }
}