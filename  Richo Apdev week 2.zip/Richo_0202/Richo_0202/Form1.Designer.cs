﻿namespace Richo_0202
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TB1 = new TextBox();
            TB2 = new TextBox();
            TB3 = new TextBox();
            TB4 = new TextBox();
            TB5 = new TextBox();
            Wordle = new Label();
            label_1 = new Label();
            label_2 = new Label();
            label_3 = new Label();
            label_4 = new Label();
            label_5 = new Label();
            button_1 = new Button();
            label_6 = new Label();
            SuspendLayout();
            // 
            // TB1
            // 
            TB1.Location = new Point(191, 58);
            TB1.Name = "TB1";
            TB1.Size = new Size(125, 27);
            TB1.TabIndex = 0;
            TB1.TextChanged += TB1_TextChanged;
            // 
            // TB2
            // 
            TB2.Location = new Point(191, 91);
            TB2.Name = "TB2";
            TB2.Size = new Size(125, 27);
            TB2.TabIndex = 1;
            TB2.TextChanged += TB2_TextChanged;
            // 
            // TB3
            // 
            TB3.Location = new Point(191, 124);
            TB3.Name = "TB3";
            TB3.Size = new Size(125, 27);
            TB3.TabIndex = 2;
            TB3.TextChanged += TB3_TextChanged;
            // 
            // TB4
            // 
            TB4.Location = new Point(191, 157);
            TB4.Name = "TB4";
            TB4.Size = new Size(125, 27);
            TB4.TabIndex = 3;
            TB4.TextChanged += TB4_TextChanged;
            // 
            // TB5
            // 
            TB5.Location = new Point(191, 190);
            TB5.Name = "TB5";
            TB5.Size = new Size(125, 27);
            TB5.TabIndex = 4;
            TB5.TextChanged += TB5_TextChanged;
            // 
            // Wordle
            // 
            Wordle.AutoSize = true;
            Wordle.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Wordle.Location = new Point(206, 22);
            Wordle.Name = "Wordle";
            Wordle.Size = new Size(96, 33);
            Wordle.TabIndex = 5;
            Wordle.Text = "Wordle";
            // 
            // label_1
            // 
            label_1.AutoSize = true;
            label_1.Location = new Point(114, 61);
            label_1.Name = "label_1";
            label_1.Size = new Size(49, 20);
            label_1.TabIndex = 6;
            label_1.Text = "Teks 1";
            // 
            // label_2
            // 
            label_2.AutoSize = true;
            label_2.Location = new Point(114, 91);
            label_2.Name = "label_2";
            label_2.Size = new Size(49, 20);
            label_2.TabIndex = 7;
            label_2.Text = "Teks 2";
            // 
            // label_3
            // 
            label_3.AutoSize = true;
            label_3.Location = new Point(114, 124);
            label_3.Name = "label_3";
            label_3.Size = new Size(49, 20);
            label_3.TabIndex = 8;
            label_3.Text = "Teks 3";
            // 
            // label_4
            // 
            label_4.AutoSize = true;
            label_4.Location = new Point(114, 157);
            label_4.Name = "label_4";
            label_4.Size = new Size(49, 20);
            label_4.TabIndex = 9;
            label_4.Text = "Teks 4";
            // 
            // label_5
            // 
            label_5.AutoSize = true;
            label_5.Location = new Point(114, 190);
            label_5.Name = "label_5";
            label_5.Size = new Size(49, 20);
            label_5.TabIndex = 10;
            label_5.Text = "Teks 5";
            // 
            // button_1
            // 
            button_1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button_1.Location = new Point(191, 238);
            button_1.Name = "button_1";
            button_1.Size = new Size(125, 36);
            button_1.TabIndex = 11;
            button_1.Text = "Main";
            button_1.UseVisualStyleBackColor = true;
            button_1.Click += button_01_Click;
            // 
            // label_6
            // 
            label_6.AutoSize = true;
            label_6.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label_6.Location = new Point(408, 116);
            label_6.Name = "label_6";
            label_6.Size = new Size(91, 33);
            label_6.TabIndex = 12;
            label_6.Text = "Status.";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1112, 324);
            Controls.Add(label_6);
            Controls.Add(button_1);
            Controls.Add(label_5);
            Controls.Add(label_4);
            Controls.Add(label_3);
            Controls.Add(label_2);
            Controls.Add(label_1);
            Controls.Add(Wordle);
            Controls.Add(TB5);
            Controls.Add(TB4);
            Controls.Add(TB3);
            Controls.Add(TB2);
            Controls.Add(TB1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TB1;
        private TextBox TB2;
        private TextBox TB3;
        private TextBox TB4;
        private TextBox TB5;
        private Label Wordle;
        private Label label_1;
        private Label label_2;
        private Label label_3;
        private Label label_4;
        private Label label_5;
        private Button button_1;
        private Label label_6;
    }
}
